Icons modified from https://www.flaticon.com/packs/greek-mythology-2

512 x 512 pixels

"580 px" Segue UI Emoji font, white text, 8 pixel stroke black outline

blue: #21bed1, red: de2e43, grey: #ced8df, green: #15dbd5, orange: #ff9a2d, blue: #003e69
